"use strict";
updateFlashDealProgressBar();
setInterval(updateFlashDealProgressBar, 10000);
